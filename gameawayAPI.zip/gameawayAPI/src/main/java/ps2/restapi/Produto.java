package ps2.restapi;

public class Produto {
    private long codigoProduto;
    private String nome;
    private Double preco;
    private String plataforma;
    private String descricao;
    private int qtd;
    


    public Produto() {}
    public Produto(long codP, String nome, Double preco, String plat, String desc, int quantidade) {
        codigoProduto = codP;
        this.nome = nome;
        this.preco = preco;
        plataforma = plat;
        descricao = desc;
        qtd = quantidade;
    }
    public long getCodigoProduto() {
        return codigoProduto;
    }
    public void setCodigoProduto(long codigoProduto) {
        this.codigoProduto = codigoProduto;
 
    }
    public int getQuantidade() {
        return qtd;
    }
    public void setQuantidade(int quantidade) {
        this.qtd = quantidade;
 
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public String getNome() {
        return nome;
    }
    public String getDescricao() { return descricao; }
    public void setDescricao(String descricao) { this.descricao = descricao; }

    public String getPlataforma() { return plataforma; }
    public void setPlataforma(String plataforma) { this.plataforma = plataforma; }

    public Double getPreco() { return preco; }
    public void setPreco(Double preco) { this.preco = preco; }
}
