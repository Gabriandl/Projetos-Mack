package ps2.restapi;


import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ProdutoController {
    private List<Produto> produtos;

    public ProdutoController(){
        this.produtos = new ArrayList<>();
        produtos.add(new Produto(1, "GTA V", 90.00, "XBOX", "Jogo de Tiro", 1));
        produtos.add(new Produto(2, "Forza", 80.00, "XBOX", "Jogo de Corrida", 1));
        produtos.add(new Produto(3, "FIFA20", 100.00, "PS4", "Jogo de Futebol", 1));
        
    }

    @GetMapping("/rest/produtos")
    Iterable<Produto> getProdutos(){
        return this.produtos;
    }

    @GetMapping("/rest/produtos/{id}")
    Optional<Produto> getProdutos(@PathVariable long id){
        for (Produto p: produtos){
            if (p.getCodigoProduto() == id) {
                return Optional.of(p);
            }
        }
        return Optional.empty();
    }
    @PostMapping("/rest/produtos")
	Produto createDisciplina(@RequestBody Produto produto) {
		long maxId = 1;
		for (Produto p: produtos) {
			if (p.getCodigoProduto() > maxId) {
				maxId = p.getCodigoProduto();
			}
		}
		produto.setCodigoProduto(maxId+1);
		produtos.add(produto);
		return produto;
	}
	
	@PutMapping("/rest/produtos/{produtoId}")
	Optional<Produto> updateProduto(@RequestBody Produto produtoRequest, @PathVariable long produtoId) {
		Optional<Produto> opt = this.getProdutos(produtoId);
		if (opt.isPresent()) {
			Produto produtos = opt.get();
			produtos.setNome(produtoRequest.getNome());
            produtos.setPlataforma(produtoRequest.getPlataforma());
            produtos.setQuantidade(produtoRequest.getQuantidade());
            produtos.setDescricao(produtoRequest.getDescricao());
            produtos.setPreco(produtoRequest.getPreco());
			
		}

		return opt;				
	}	
	
	@DeleteMapping(value = "/rest/produto/{id}")
	void deleteProduto(@PathVariable long id) {
		produtos.removeIf(p -> p.getCodigoProduto() == id);
	}		
}
