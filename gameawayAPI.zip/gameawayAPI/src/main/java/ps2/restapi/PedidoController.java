package ps2.restapi;


import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PedidoController {
    
    private List<Pedido> pedidos;

    public PedidoController(){
        
        List<Produto> l1 =  new ArrayList<>(); l1.add(new Produto(1, "GTA V", 90.00, "XBOX", "Jogo de Tiro", 2)); l1.add(new Produto(2, "Forza", 80.00, "XBOX", "Jogo de Corrida", 3));
        List<Produto> l2 =  new ArrayList<>();  l2.add(new Produto(2, "Forza", 80.00, "XBOX", "Jogo de Corrida", 3));
        this.pedidos = new ArrayList<>();
        pedidos.add(new Pedido(1, l1, 123));
        pedidos.add(new Pedido(2, l2, 456));
    }

    @GetMapping("/rest/pedidos")
    Iterable<Pedido> getPedidos(){
        return this.pedidos;
    }

    @GetMapping("/rest/pedidos/{id}")
    Optional<Pedido> getPedido(@PathVariable long id){
        for (Pedido p: pedidos){
            if (p.getIdPedido() == id) {
                return Optional.of(p);
            }
        }
        return Optional.empty();
    }
    @PostMapping("/rest/pedidos")
	Pedido createDisciplina(@RequestBody Pedido pedido) {
		long maxId = 1;
		for (Pedido p: pedidos) {
			if (p.getIdPedido() > maxId) {
				maxId = p.getIdPedido();
			}
		}
		pedido.setIdPedido(maxId+1);
		pedidos.add(pedido);
		return pedido;
	}
	
	@PutMapping("/rest/pedidos/{pedidoId}")
	Optional<Pedido> updatePedido(@RequestBody Pedido pedidoRequest, @PathVariable long pedidoId) {
		Optional<Pedido> opt = this.getPedido(pedidoId);
		if (opt.isPresent()) {
			Pedido pedido = opt.get();
			pedido.setIdPedido(pedidoRequest.getIdPedido());
            pedido.setLista(pedidoRequest.getListaProdutos());
         //   pedido.setSubtotal(pedidoRequest.getSubtotal());
            pedido.setIdVendedor(pedidoRequest.getIdVendedor());
         //   pedido.setDataHoraPedido(pedidoRequest.getDataHoraPedido());
			
		}

		return opt;				
	}	
	
	@DeleteMapping(value = "/rest/pedidos/{id}")
	void deleteDisciplina(@PathVariable long id) {
		pedidos.removeIf(p -> p.getIdPedido() == id);
	}		
}
