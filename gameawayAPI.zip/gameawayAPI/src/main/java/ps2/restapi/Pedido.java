package ps2.restapi;

import java.time.Instant;

import java.util.List;

public class Pedido {

    private long idPedido;
    private List<Produto> listaProdutos;
    private Double subTotal;
    private Instant dataHoraPedido ;
    private int idVendedor;


    public Pedido() {}
    public Pedido(long idp, List<Produto> l, int idV) {
        idPedido = idp;
        this.listaProdutos = l;
        idVendedor= idV;
    }
 
    public void setIdPedido(long idPedido) {
        this.idPedido = idPedido;
    }
    public long getIdPedido() {
        return idPedido;
    }
    public Double getSubtotal() { 

        subTotal=0.0;
        for (int i = 0; i < listaProdutos.size(); i++){

        Produto produto = this.listaProdutos.get(i);
        int qtd = produto.getQuantidade();
        Double preco = produto.getPreco();
        subTotal =subTotal+ (qtd*preco);

        }

        return subTotal; }

   public void setSubtotal(Double subtotal) {
        this.subTotal = subtotal;
    }

    public List<Produto> getListaProdutos() { return listaProdutos; }

    public void setLista(List<Produto> l) { listaProdutos= l; }

    public void setIdVendedor(int idv) {
        this.idVendedor = idv;
    }
    public int getIdVendedor() {
        return idVendedor;
    }

    public void setDataHoraPedido(Instant dataHora) {
        this.dataHoraPedido = dataHora;
    }
    public Instant getDataHoraPedido() {
        dataHoraPedido = Instant.now() ;
        return dataHoraPedido;
    }
    

   
}